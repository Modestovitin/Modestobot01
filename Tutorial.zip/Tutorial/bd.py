message_ids1 = True
mensage_delete1 = True
dados = True